#!/bin/bash

BASE_URL="http://localhost:3000/users"

echo "🔍 GET - Listar todos os usuários"
curl -s -X GET $BASE_URL | jq
echo -e "\n--------------------------\n"

echo "➕ POST - Criar novo usuário"
RESPONSE=$(curl -s -X POST $BASE_URL \
  -H "Content-Type: application/json" \
  -d '{
    "nome": "Maria Oliveira",
    "email": "maria.oliveira@example.com",
    "telefone": "(21) 98765-4321"
}')
echo "$RESPONSE" | jq
USER_ID=$(echo "$RESPONSE" | jq -r '.[0].id')
echo -e "\nUsuário criado com ID: $USER_ID"
echo -e "\n--------------------------\n"

echo "🔍 GET - Buscar usuário criado (ID: $USER_ID)"
curl -s -X GET $BASE_URL/$USER_ID | jq
echo -e "\n--------------------------\n"

echo "✏️ PUT - Atualizar usuário (ID: $USER_ID)"
curl -s -X PUT $BASE_URL/$USER_ID \
  -H "Content-Type: application/json" \
  -d '{
    "nome": "Maria de Oliveira",
    "email": "maria.de.oliveira@example.com",
    "telefone": "(21) 99999-0000"
}' | jq
echo -e "\n--------------------------\n"

echo "❌ DELETE - Remover usuário (ID: $USER_ID)"
curl -s -X DELETE $BASE_URL/$USER_ID
echo -e "\nUsuário deletado."
echo -e "\n--------------------------\n"

echo "✅ Finalizado!"
