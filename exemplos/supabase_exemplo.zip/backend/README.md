# Exemplo de código web com frontend e backend utilizando supabase (PostgreSQL)

🧰 1. Pré-requisitos do backend:
- Node.js instalado (node -v para verificar)
- Supabase com o projeto e tabela users criada
- Variáveis de ambiente .env com sua URL e chave da API

🧰 2. Pré-requisitos do frontend:
- Navegador web (sugestão: Google Chrome)

📦 3. Colocando o backend em funcionamento:
- Renomeie o exemplo `DOT.env` para `.env`
- Edite o arquivo `.env` e coloque a URL do seu projeto e a chave pública
- Se tiver dúvidas sobre a criação de uma tabela para testes, leia o `supabaseQS.pdf`.
- Instale as dependências do projeto:
```
npm install
-ou-
npm i
-ou-
npm install express dotenv @supabase/supabase-js cors
```

🚀 4. Rode o backend

No terminal, dentro do diretório do projeto:
```
$ node index.js
```

🚀 5. Rode o frontend

Abra o arquivo `index.html` em seu navegador
