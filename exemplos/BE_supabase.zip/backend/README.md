


🧰 1. Pré-requisitos do backend:
- Node.js instalado (node -v para verificar)
- Supabase com o projeto e tabela users criada
- Variáveis de ambiente .env com sua URL e chave da API

📦 2. Instale as dependências
```
npm install express dotenv @supabase/supabase-js
-ou-
npm i
```
🚀 6. Rode o backend

No terminal, dentro do diretório do projeto:
```
$ node index.js
```


📦 4. Requisitos para testes:
- O comando jq para formatar JSON (pode instalar com sudo apt install jq ou brew install jq)
- Permissão para executar o script: chmod +x test_api.sh
- API rodando em http://localhost:3000
- Execute o script:
```
$ ./test_api.sh
```

## Informações sobre o teste da API:

- GET /users – lista todos
```
$ curl -X GET http://localhost:3000/users
```

- GET /users/:id – busca um por ID
```
curl -X GET http://localhost:3000/users/1
```

- POST /users – cria um novo usuário
```
curl -X POST http://localhost:3000/users \
  -H "Content-Type: application/json" \
  -d '{
    "nome": "João Silva",
    "email": "joao.silva@example.com",
    "telefone": "(11) 91234-5678"
}'
```

- PUT /users/:id – atualiza um usuário
```
curl -X PUT http://localhost:3000/users/1 \
  -H "Content-Type: application/json" \
  -d '{
    "nome": "João da Silva",
    "email": "joaodasilva@example.com",
    "telefone": "(11) 99876-5432"
}'
```

- DELETE /users/:id – remove um usuário
```
curl -X DELETE http://localhost:3000/users/1
```

